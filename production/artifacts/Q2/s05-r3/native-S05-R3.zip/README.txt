Q2 native VSE projects, Blender 4.3.2. Open project/S05.blend.
Textures are relative and SHA256-addressed. Source JSON preserves authored frames.
These are benchmark fixtures, not the story pilot or production release.
Original artwork belongs to this project; voice is not embedded in these image-strip files.
Repository: https://github.com/maitoan2408/ai-animation-studio-research-content
See production/ENVIRONMENT.md for licenses; Q1 listening review remains open.

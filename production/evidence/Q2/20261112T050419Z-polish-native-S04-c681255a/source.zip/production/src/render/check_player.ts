/** Actual Chromium video playback/decode/color sampling against a native PNG.
 * This records target-player evidence. Audio perception and artistic approval
 * are not inferred from playback success or a pixel measurement. */
import {createServer} from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import puppeteer from 'puppeteer-core';
import {root} from './server.js';
const dir=path.resolve(process.argv[2]!),frame=Number(process.argv[3]??72);
if(!Number.isInteger(frame)||frame<0)throw Error('INVALID_FRAME');
const video=await readFile(path.join(dir,'delivery.mp4'));
const out=path.join(root,'out/player-check',randomUUID());await mkdir(out,{recursive:true});
const server=createServer((req,res)=>{
 if(req.url==='/video.mp4'){res.setHeader('content-type','video/mp4');res.end(video);}
 else res.end('<body style="margin:0"><video id="v" muted preload="auto" src="/video.mp4" style="position:absolute;left:-10000px"></video><canvas id="c" width="1920" height="1080"></canvas></body>');
});
await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const addr=server.address();if(!addr||typeof addr==='string')throw Error('NO_PORT');
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']});
try{
 const page=await browser.newPage();await page.setViewport({width:1920,height:1080,deviceScaleFactor:1});await page.goto(`http://127.0.0.1:${addr.port}`);
 const report=await page.evaluate(async(f:number)=>{
  const v=document.querySelector('video')!,c=document.querySelector('canvas')!,ctx=c.getContext('2d',{colorSpace:'srgb'})!;
  if(v.readyState<2)await new Promise<void>(r=>v.addEventListener('loadeddata',()=>r(),{once:true}));
  v.currentTime=(f+.1)/24;await new Promise<void>(r=>v.addEventListener('seeked',()=>r(),{once:true}));ctx.drawImage(v,0,0);
  const sampled=c.toDataURL('image/png');v.currentTime=0;await new Promise<void>(r=>v.addEventListener('seeked',()=>r(),{once:true}));
  const began=performance.now();await v.play();await new Promise<void>((resolve,reject)=>{v.addEventListener('ended',()=>resolve(),{once:true});v.addEventListener('error',()=>reject(Error('VIDEO_PLAYBACK_ERROR')),{once:true});});
  const quality=v.getVideoPlaybackQuality();return {sampled,elapsedSeconds:(performance.now()-began)/1000,duration:v.duration,ended:v.ended,width:v.videoWidth,height:v.videoHeight,decoded:quality.totalVideoFrames,dropped:quality.droppedVideoFrames};
 },frame);
 await writeFile(path.join(out,'player.png'),Buffer.from(report.sampled.split(',')[1]!,'base64'));
 const {sampled,...metadata}=report;await writeFile(path.join(out,'report.json'),JSON.stringify({frame,browser:await browser.version(),...metadata,scope:'Actual 1x HTML video playback, muted; no listening/creative gate'},null,2)+'\n');
 console.log(JSON.stringify({output:out,...metadata}));
}finally{await browser.close();server.closeAllConnections();server.close();}

"""Repair missing transitive lock entries outside the existing install tree.

Exact direct pins cannot change. The old/new lock diff and clean-install tests
are separate evidence. This utility never installs into the live workbench.
"""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
source = ROOT / 'production'
temporary = Path(tempfile.mkdtemp(prefix='studio-lock-repair-'))
for name in ['package.json','package-lock.json']:
    shutil.copy2(source / name, temporary / name)
before = json.loads((source / 'package-lock.json').read_text())
subprocess.run(['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund',
                '--cache',str(temporary / 'cache')], cwd=temporary, check=True)
after = json.loads((temporary / 'package-lock.json').read_text())
for field in ['dependencies','devDependencies']:
    if before['packages'][''].get(field) != after['packages'][''].get(field):
        raise RuntimeError('DIRECT_PINS_CHANGED')
removed = sorted(set(before['packages']) - set(after['packages']))
changed_versions = [{ 'package': name, 'before': before['packages'][name].get('version'),
                      'after': after['packages'][name].get('version')}
                    for name in before['packages'] if name in after['packages'] and
                    before['packages'][name].get('version') != after['packages'][name].get('version')]
if removed or changed_versions:
    raise RuntimeError('UNEXPECTED_RESOLUTION_CHANGE '+json.dumps({'removed':removed,'versions':changed_versions}))
shutil.copy2(temporary / 'package-lock.json', source / 'package-lock.json')
print(json.dumps({'status':'LOCK_REPAIRED_PENDING_CLEAN_TEST','added':sorted(set(after['packages'])-set(before['packages'])),
                  'directPinsUnchanged':True,'existingVersionsUnchanged':True,'scratch':str(temporary)}))

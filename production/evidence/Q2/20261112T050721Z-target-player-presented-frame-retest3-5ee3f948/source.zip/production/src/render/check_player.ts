/** Actual Chromium video playback/decode/color sampling against a native PNG.
 * This records target-player evidence. Audio perception and artistic approval
 * are not inferred from playback success or a pixel measurement. */
import {createServer} from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import puppeteer from 'puppeteer-core';
import {root} from './server.js';
const dir=path.resolve(process.argv[2]!),frame=Number(process.argv[3]??72);
if(!Number.isInteger(frame)||frame<0)throw Error('INVALID_FRAME');
const video=await readFile(path.join(dir,'delivery.mp4'));
const out=path.join(root,'out/player-check',randomUUID());await mkdir(out,{recursive:true});
const server=createServer((req,res)=>{
 if(req.url==='/video.mp4'){res.setHeader('content-type','video/mp4');res.end(video);}
 else res.end('<body style="margin:0"><video id="v" muted preload="auto" src="/video.mp4" style="width:1920px;height:1080px"></video><canvas id="c" width="1920" height="1080" style="display:none"></canvas></body>');
});
await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const addr=server.address();if(!addr||typeof addr==='string')throw Error('NO_PORT');
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']});
try{
 const page=await browser.newPage();await page.setViewport({width:1920,height:1080,deviceScaleFactor:1});await page.goto(`http://127.0.0.1:${addr.port}`);
 // A fixed browser script avoids tsx injecting Node-only __name helpers.
 const report=await page.evaluate(`(async()=>{const f=${frame};
  const v=document.querySelector('video'),c=document.querySelector('canvas'),ctx=c.getContext('2d',{colorSpace:'srgb'});
  if(v.readyState<2)await new Promise(r=>v.addEventListener('loadeddata',()=>r(),{once:true}));
  // seeked alone can leave the old decoded image on an off-screen video.
  // Keep the video visible and require compositor mediaTime, not currentTime.
  const seekPresented=async(frame)=>new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('PRESENTED_FRAME_TIMEOUT')),10000);
   const observe=(_now,meta)=>{
    if(Math.abs(meta.mediaTime-frame/24)<1/48){clearTimeout(timer);resolve(meta.mediaTime);}
    else v.requestVideoFrameCallback(observe);
   };
   v.requestVideoFrameCallback(observe);v.currentTime=(frame+.1)/24;
  });
  const presentedMediaTime=await seekPresented(f);ctx.drawImage(v,0,0);
  const sampled=c.toDataURL('image/png');await seekPresented(0);
  const began=performance.now();await v.play();await new Promise((resolve,reject)=>{v.addEventListener('ended',()=>resolve(),{once:true});v.addEventListener('error',()=>reject(Error('VIDEO_PLAYBACK_ERROR')),{once:true});});
  const quality=v.getVideoPlaybackQuality();return {sampled,presentedMediaTime,elapsedSeconds:(performance.now()-began)/1000,duration:v.duration,ended:v.ended,width:v.videoWidth,height:v.videoHeight,decoded:quality.totalVideoFrames,dropped:quality.droppedVideoFrames};
 })()` ) as {sampled:string;presentedMediaTime:number;elapsedSeconds:number;duration:number;ended:boolean;width:number;height:number;decoded:number;dropped:number};
 await writeFile(path.join(out,'player.png'),Buffer.from(report.sampled.split(',')[1]!,'base64'));
 const {sampled,...metadata}=report;await writeFile(path.join(out,'report.json'),JSON.stringify({frame,browser:await browser.version(),...metadata,scope:'Actual 1x HTML video playback, muted; no listening/creative gate'},null,2)+'\n');
 console.log(JSON.stringify({output:out,...metadata}));
}finally{await browser.close();server.closeAllConnections();server.close();}

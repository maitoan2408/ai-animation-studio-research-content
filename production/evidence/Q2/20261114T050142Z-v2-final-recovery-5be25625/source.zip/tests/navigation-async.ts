import assert from 'node:assert/strict';
import puppeteer, { type HTTPRequest } from 'puppeteer-core';
import { mkdtemp, rm } from 'node:fs/promises';
import { Studio } from '../src/application.js';
import { serve } from '../src/server.js';
const dir = await mkdtemp('/tmp/v2-nav-');
const app = await Studio.open(dir);
const a = await app.create('Hello', 'First');
const b = await app.create('World', 'Second');
const server = await serve(app, 0);
const browser = await puppeteer.launch({
  executablePath: '/usr/bin/chromium',
  headless: true,
  args: ['--no-sandbox', '--disable-dev-shm-usage'],
});
try {
  const page = await browser.newPage();
  await page.goto(server.url);
  await page.waitForSelector(`[data-project="${a.id}"]`);
  await page.click(`[data-project="${a.id}"]`);
  await page.waitForSelector('[data-scene="s001"] [name="title"]');
  let unblock: (() => Promise<void>) | undefined;
  let resolveCapture: (() => void) | undefined;
  const captured = new Promise<void>((r) => {
    resolveCapture = r;
  });
  await page.setRequestInterception(true);
  page.on('request', (r: HTTPRequest) => {
    if (r.method() === 'GET' && r.url().endsWith('/projects/' + b.id)) {
      unblock = async () => {
        await r.continue();
      };
      resolveCapture?.();
    } else void r.continue();
  });
  await page.click(`[data-project="${b.id}"]`);
  await captured;
  const reloaded = page.waitForResponse((response) => response.url().endsWith('/projects/' + a.id));
  await page.click(`[data-project="${a.id}"]`);
  await reloaded;
  await new Promise((r) => setTimeout(r, 100));
  await page.waitForFunction(() => document.querySelector('#heading')?.textContent === 'First');
  await page.$eval('[data-scene="s001"] [name="title"]', (e) => {
    (e as HTMLInputElement).value = 'New draft';
    e.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await unblock!();
  await new Promise((r) => setTimeout(r, 700));
  assert.equal(
    await page.$eval('#heading', (e) => e.textContent),
    'First',
    'stale project load must not replace current project',
  );
  assert.equal(
    await page.$eval('[data-scene="s001"] [name="title"]', (e) => (e as HTMLInputElement).value),
    'New draft',
  );
  console.log('PASS stale navigation keeps project and draft');
} finally {
  await browser.close();
  await server.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
}

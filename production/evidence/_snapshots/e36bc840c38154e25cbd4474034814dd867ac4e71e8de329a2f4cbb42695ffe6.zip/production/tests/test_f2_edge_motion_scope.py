import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src/art/paper-scene/calibration/edge_motion_scope.py';s=importlib.util.spec_from_file_location('edge_scope',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class EdgeMotionScopeTest(unittest.TestCase):
 def test_bbox_rotation_and_flip(self):
  a={'width':60,'height':30,'pivot':[30,15]};s={'x':960,'y':540,'rotation':0,'scaleX':1,'scaleY':1};c={'x':960,'y':540,'zoom':1}
  self.assertEqual(m.box_for(s,a,c,margin=0),(310,175,330,185));s['rotation']=90
  self.assertEqual(m.box_for(s,a,c,margin=0),(315,170,325,190));s['scaleX']=-1
  self.assertEqual(m.box_for(s,a,c,margin=0),(315,170,325,190))

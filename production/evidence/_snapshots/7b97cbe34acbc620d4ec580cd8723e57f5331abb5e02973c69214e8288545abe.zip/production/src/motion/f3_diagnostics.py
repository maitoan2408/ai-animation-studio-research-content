"""Selected-image diagnostics for one hashed F3 hero-life preview; not an art gate."""
import hashlib,json,math,sys
from pathlib import Path
from PIL import Image,ImageDraw
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def sha(b):return hashlib.sha256(b).hexdigest()
def derivative(values,fps):
 if len(values)<2 or not math.isfinite(fps) or fps<=0 or not all(math.isfinite(x) for x in values):raise ValueError('F3_DIAGNOSTIC_TRACE')
 return [(b-a)*fps for a,b in zip(values,values[1:])]
def generate(source,preview,out):
 source,preview,out=Path(source),Path(preview),Path(out)
 raw=source.read_bytes();data=json.loads(raw);report=json.loads((preview/'report.json').read_text())
 if data['edit']['qualityCandidate']!='f3-hero-life' or len(data['frames'])!=192 or report['sourceSha256']!=sha(raw) or report['frames']!=192 or report['fps']!='24/1':raise ValueError('F3_DIAGNOSTIC_SOURCE')
 if len(report['frameSha256'])!=192 or sha((preview/'preview.mp4').read_bytes())!=report['videoSha256']:raise ValueError('F3_DIAGNOSTIC_VIDEO')
 pngs=[]
 for frame in range(192):
  b=(preview/'frames'/f'{frame:04}.png').read_bytes()
  if sha(b)!=report['frameSha256'][frame]:raise ValueError('F3_DIAGNOSTIC_FRAME_HASH')
  pngs.append(b)
 if out.exists():raise ValueError('F3_DIAGNOSTIC_TARGET_EXISTS')
 out.mkdir(parents=True)
 from io import BytesIO
 picks=[0,24,60,72,90,108,158,191];sheet=Image.new('RGB',(1280,760),'#f4f1e8');draw=ImageDraw.Draw(sheet)
 for i,frame in enumerate(picks):
  image=Image.open(BytesIO(pngs[frame])).convert('RGB');image.thumbnail((320,180));x=(i%4)*320;y=(i//4)*380
  sheet.paste(image,(x,y+24));draw.text((x+8,y+5),f'Frame {frame}',fill='#183b38')
 sheet.save(out/'contact-sheet.png',optimize=True)
 frames=[86,88,90,92,94];onion=Image.open(BytesIO(pngs[frames[0]])).convert('RGB')
 for count,frame in enumerate(frames[1:],start=2):onion=Image.blend(onion,Image.open(BytesIO(pngs[frame])).convert('RGB'),1/count)
 onion.save(out/'onion-86-94.png',optimize=True)
 heads=[];torsos=[];blink=[]
 for frame in data['frames']:
  head=next(s for s in frame['sprites'] if s['id']=='mai.head');torso=next(s for s in frame['sprites'] if s['id']=='mai.torso')
  heads.append(head['rotation']);torsos.append(torso['y']);blink.append(int(head['asset'].endswith('-blink')))
 velocity=derivative(heads,24);acceleration=derivative(velocity,24);jerk=derivative(acceleration,24)
 fig,axes=plt.subplots(3,1,figsize=(9,6),sharex=True)
 for ax,values,label in zip(axes,[heads,torsos,blink],['Head angle (degrees)','Torso pivot y (stage px)','Blink asset active']):
  ax.plot(range(192),values,lw=1.2);ax.set_ylabel(label);ax.grid(alpha=.25)
 axes[-1].set_xlabel('Frame, 24 fps');fig.suptitle('S05 life fixture — observations, no acting score');fig.tight_layout();fig.savefig(out/'curves.png',dpi=120);plt.close(fig)
 result={'status':'OBSERVATION_ONLY','sourceSha256':sha(raw),'videoSha256':report['videoSha256'],'frames':192,'contactFrames':picks,'onionFrames':frames,
 'maxHeadJerkDegreesPerSecondCubed':max(map(abs,jerk)),'blinkFrames':sum(blink),
 'limits':['finite differences use unfiltered frame samples; no locked jerk threshold','contact sheet and blended onion are not art approval','preview 640x360, no audio']}
 (out/'report.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 if len(sys.argv)!=4:raise SystemExit('usage: f3_diagnostics.py SOURCE PREVIEW OUTPUT')
 print(json.dumps(generate(*sys.argv[1:])))

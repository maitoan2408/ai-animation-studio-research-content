"""Validate and retain small crops of six separate native-size experiments."""
import hashlib,importlib.util,json,sys
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[5]
module=importlib.util.spec_from_file_location('paper_verify',ROOT/'production/src/art/paper-scene/verify_comparison.py');verify=importlib.util.module_from_spec(module);module.loader.exec_module(verify)
REGIONS={'face_mai':(620,170,820,390),'hand_lantern':(825,470,1000,710),'feet_ground':(600,840,880,970)}
def run(log,target):
 target=Path(target);target.mkdir(parents=True,exist_ok=True);records=[];seen=set();source=contour=None
 for line in Path(log).read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if r.get('status')!='PARTIAL_SCENE_EXPERIMENT':continue
  pair=(r.get('look'),r.get('frame'))
  if pair in seen or pair not in {(v,f) for v in ('edge-alpha','bump','lamp-light') for f in (0,191)}:raise ValueError('ENDPOINT_UNEXPECTED')
  seen.add(pair);out=Path(r['output']).resolve()
  if not out.is_relative_to((ROOT/'production/out/paper-scene').resolve()):raise ValueError('ENDPOINT_PATH')
  actual=json.loads((out/'report.json').read_text())
  if r!=actual:raise ValueError('ENDPOINT_REPORT')
  if source is None:source,contour=r['inputSha256'],r['contourSha256']
  if (source,contour)!=(r['inputSha256'],r['contourSha256']) or r['coverage']!='physical' or r['shadowMode']!='authored-only':raise ValueError('ENDPOINT_BINDING')
  check=verify.verify(out);image=Image.open(out/'volume.png').convert('RGB');crops={}
  for name,box in REGIONS.items():
   name_out=f'{pair[0]}-{pair[1]:03}-{name}.png';file=target/name_out;image.crop(box).save(file,optimize=True)
   crops[name]={'box':box,'file':name_out,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
  records.append({'look':pair[0],'frame':pair[1],'sourceImageSha256':check['volumeSha256'],'flatImageSha256':check['flatSha256'],'smokeChangedPixels':check['changedPixels'],'crops':crops})
 if len(seen)!=6:raise ValueError('ENDPOINT_MISSING')
 result={'status':'PASS_PROVISIONAL_NATIVE_ENDPOINTS','dimensions':[1920,1080],'sourceSha256':source,'contourSha256':contour,'records':records,'scope':'separate look experiments, frame endpoints only; no combined preset, full 1080 motion, flicker, shadows or artistic approval'}
 (target/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('usage: native_endpoints.py RENDER_STDOUT OUTPUT_DIR')
 run(*sys.argv[1:])

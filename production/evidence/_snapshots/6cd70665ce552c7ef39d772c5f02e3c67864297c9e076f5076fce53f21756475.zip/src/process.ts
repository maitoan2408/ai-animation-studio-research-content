import { spawn } from 'node:child_process';
import { StudioError } from './domain.js';

/** Argument arrays only: project text never becomes shell code. */
export function run(
  command: string,
  args: string[],
  signal?: AbortSignal,
  onOutput?: (chunk: string) => void,
): Promise<string> {
  return new Promise((resolve, reject) => {
    signal?.throwIfAborted();
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'], signal });
    let stdout = '',
      stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout = (stdout + String(chunk)).slice(-2_000_000);
      onOutput?.(String(chunk));
    });
    child.stderr.on('data', (chunk) => {
      stderr = (stderr + String(chunk)).slice(-12000);
      onOutput?.(String(chunk));
    });
    child.on('error', reject);
    child.on('close', (code) =>
      code === 0
        ? resolve(stdout)
        : reject(
            new StudioError(
              'PROCESS_FAILED',
              `${command} exited ${code}: ${stderr.slice(-2500)}`,
              500,
            ),
          ),
    );
  });
}

export async function doctor() {
  const browser = process.env.STUDIO_BROWSER ?? '/usr/bin/chromium';
  const [ffmpeg, ffprobe, chromium, rasterizer] = await Promise.all([
    run('ffmpeg', ['-version']),
    run('ffprobe', ['-version']),
    run(browser, ['--version']),
    run('rsvg-convert', ['--version']).catch(() => {
      throw new StudioError(
        'RASTERIZER_UNAVAILABLE',
        'Không chạy được rsvg-convert. Cài librsvg2-bin (Debian/Ubuntu) và kiểm tra PATH trước khi render.',
        503,
      );
    }),
  ]);
  return {
    node: process.version,
    ffmpeg: ffmpeg.split('\n')[0]!,
    ffprobe: ffprobe.split('\n')[0]!,
    chromium: chromium.trim(),
    browser,
    rasterizer: rasterizer.trim(),
    backend: 'HyperFrames 0.9.30 / native librsvg segments',
    compiler: 'paper-studio/2',
  };
}

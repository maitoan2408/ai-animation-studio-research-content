import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { doctor } from '../src/process.js';
import { StudioError } from '../src/domain.js';

test('doctor fails helpfully on missing rasterizer and recovers after installation', async (t) => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'studio-doctor-'));
  const oldPath = process.env.PATH,
    oldBrowser = process.env.STUDIO_BROWSER;
  t.after(async () => {
    process.env.PATH = oldPath;
    if (oldBrowser === undefined) delete process.env.STUDIO_BROWSER;
    else process.env.STUDIO_BROWSER = oldBrowser;
    await rm(dir, { recursive: true, force: true });
  });
  for (const name of ['ffmpeg', 'ffprobe', 'browser'])
    await writeFile(path.join(dir, name), '#!/bin/sh\necho fixture-version\n', { mode: 0o755 });
  process.env.PATH = dir;
  process.env.STUDIO_BROWSER = path.join(dir, 'browser');
  await assert.rejects(
    doctor,
    (error: unknown) =>
      error instanceof StudioError &&
      error.code === 'RASTERIZER_UNAVAILABLE' &&
      /librsvg2-bin/.test(error.message),
  );
  await writeFile(
    path.join(dir, 'rsvg-convert'),
    '#!/bin/sh\necho rsvg-convert-version-fixture\n',
    { mode: 0o755 },
  );
  assert.match(JSON.stringify(await doctor()), /rsvg-convert-version-fixture/);
});

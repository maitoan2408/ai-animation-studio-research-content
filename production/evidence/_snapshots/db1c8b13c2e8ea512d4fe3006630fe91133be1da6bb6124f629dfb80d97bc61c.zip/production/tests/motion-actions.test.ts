import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { sampleAction, type ActionSpec } from '../src/motion/actions.js';
import { actorSprites } from '../src/scene/rig.js';
import { anchorPoint } from '../src/scene/geometry.js';
import type { ArtPack } from '../src/scene/types.js';
const pack = JSON.parse(await readFile(new URL('../assets/lantern-polish-1/manifest.json', import.meta.url), 'utf8')) as ArtPack;
for (const action of ['turn-head', 'wave'] as const) test(`${action} samples the actual rig with stable contact and exact endpoints`, () => {
 const spec: ActionSpec = { action, duration: 48, intensity: 1, onTwos: false };
 const first = actorSprites(pack, sampleAction(spec, 0));
 assert.deepEqual(actorSprites(pack, sampleAction(spec, 48)), first);
 const middle = actorSprites(pack, sampleAction(spec, 24));
 assert.notDeepEqual(middle.sprites, first.sprites);
 for (let f = 0; f <= 48; f++) {
  const pose = actorSprites(pack, sampleAction(spec, f));
  for (const id of ['mai.left-boot', 'mai.right-boot']) {
   const boot = pose.sprites.find(s => s.id === id)!;
   const initial = first.sprites.find(s => s.id === id)!;
   assert.deepEqual(anchorPoint(pack, boot, 'sole'), anchorPoint(pack, initial, 'sole'));
  }
  assert.ok(pose.sprites.every(s => [s.x,s.y,s.rotation,s.scaleX,s.scaleY].every(Number.isFinite)));
 }
 for (const f of [48,0,25,12,25]) assert.deepEqual(sampleAction(spec, f), sampleAction(spec, f));
 const twos = { ...spec, onTwos: true }; assert.deepEqual(sampleAction(twos, 10), sampleAction(twos, 11));
 assert.notDeepEqual(sampleAction(spec, 12), sampleAction({ ...spec, duration: 96 }, 12));
 assert.notDeepEqual(sampleAction(spec, 24), sampleAction({ ...spec, intensity: .5 }, 24));
});
test('action boundary rejects unsupported inputs', () => {
 const spec: ActionSpec = { action:'wave', duration:48, intensity:1, onTwos:false };
 for (const invalid of [{...spec, action:'walk'}, {...spec, duration:25}, {...spec, intensity:1.1}, {...spec, onTwos:1}, {...spec, unsupported:true}])
  assert.throws(() => sampleAction(invalid as ActionSpec, 0), /ACTION_SPEC_INVALID/);
 for (const frame of [-1,49,.5]) assert.throws(() => sampleAction(spec, frame), /ACTION_FRAME_INVALID/);
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {makePaperGeometry} from '../src/art/paper-spike/geometry.js';
test('paper plate and extruded shape share the authored native pivot',()=>{
 const shape=new THREE.Shape();shape.moveTo(0,0);shape.lineTo(180,0);shape.lineTo(180,190);shape.lineTo(0,190);shape.closePath();
 const {face,body}=makePaperGeometry(shape,{width:180,height:190,pivot:[90,170]},3);
 face.computeBoundingBox();body.computeBoundingBox();
 for(const bounds of [face.boundingBox!,body.boundingBox!]){
  assert.equal(bounds.min.x,-90);assert.equal(bounds.max.x,90);
  assert.equal(bounds.min.y,-20);assert.equal(bounds.max.y,170);
 }
 assert.equal(body.boundingBox!.min.z,0);assert.equal(body.boundingBox!.max.z,3);
 face.dispose();body.dispose();
});
test('paper geometry rejects missing pivot, nonfinite dimensions and depth',()=>{
 const shape=new THREE.Shape();
 assert.throws(()=>makePaperGeometry(shape,{width:0,height:10,pivot:[0,0]},3),/PAPER_GEOMETRY/);
 assert.throws(()=>makePaperGeometry(shape,{width:10,height:10,pivot:[NaN,0]},3),/PAPER_GEOMETRY/);
 assert.throws(()=>makePaperGeometry(shape,{width:10,height:10,pivot:[0,0]},0),/PAPER_GEOMETRY/);
});

import importlib.util
from pathlib import Path
import unittest
spec=importlib.util.spec_from_file_location('trace',Path(__file__).resolve().parents[1]/'src/art/paper-silhouette/trace.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class SilhouetteTrace(unittest.TestCase):
    def test_solid_hole_diagonal_and_transparent(self):
        single=mod.trace([1]*9,3,3);self.assertEqual(len(single),1);self.assertEqual(single[0]['signedArea'],9)
        hole=mod.trace([1,1,1,1,0,1,1,1,1],3,3);self.assertEqual(sorted(x['signedArea'] for x in hole),[-1,9])
        diag=mod.trace([1,0,0,1],2,2);self.assertEqual(sorted(x['signedArea'] for x in diag),[1,1])
        self.assertEqual(mod.trace([0]*9,3,3),[])
    def test_invalid_mask_rejects(self):
        with self.assertRaisesRegex(ValueError,'SILHOUETTE_MASK'):mod.trace([1],2,2)
if __name__=='__main__': unittest.main()

import subprocess,sys,tempfile,unittest
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]
VERIFY=ROOT/'production/src/art/paper-scene/calibration/shadow_verify.py'
class ShadowFixtureVerifierTest(unittest.TestCase):
 def test_rejects_no_shadow_and_leak(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);base=Image.new('RGB',(400,200),'white');base.save(d/'off.png');base.save(d/'same.png')
   run=lambda x:subprocess.run([sys.executable,str(VERIFY),str(d/'off.png'),str(x)],capture_output=True)
   self.assertNotEqual(run(d/'same.png').returncode,0)
   shadow=base.copy()
   for x in range(70,80):
    for y in range(50,60):shadow.putpixel((x,y),(80,80,80))
   shadow.save(d/'inside.png');self.assertEqual(run(d/'inside.png').returncode,0)
   shadow.putpixel((0,0),(0,0,0));shadow.save(d/'leak.png');self.assertNotEqual(run(d/'leak.png').returncode,0)
